#!/bin/bash

# Funktion zum Ändern des Terminal-Prompts
change_prompt() {
    PS1="root@localhost:\w/# "
}

# Ändern des Terminal-Prompts
change_prompt

# Starten des interaktiven Terminals
bash --rcfile <(echo '. ~/.bashrc; . ~/.bash_profile;')