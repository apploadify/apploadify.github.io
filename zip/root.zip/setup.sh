#!/bin/bash

# Setzen der Ausführrechte für root.sh
chmod +x ~/.root/root.sh

# Erstellen des Alias in ~/.bash_profile
echo "alias root_start='~/.root/root.sh'" >> ~/.bash_profile

# Aktualisieren der Bash-Profile
source ~/.bash_profile

# Starten von root.sh
~/.root/root.sh