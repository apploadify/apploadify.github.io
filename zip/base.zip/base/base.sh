#!/bin/bash

echo "Start Base Installation"

pkg update && pkg upgrade

pkg install python && pkg install x11-repo && pkg install tigervnc && pkg install python-tkinter && pkg install openjdk-17 && pkg install kotlin

echo "Installation Succesful8"