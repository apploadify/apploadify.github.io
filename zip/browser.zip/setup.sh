#!/bin/bash

echo 'alias open=/data/data/com.termux/files/home/open.sh"' > ~/.bashrc

echo "Pls use the Command: source ~/.bashrc for setup "
