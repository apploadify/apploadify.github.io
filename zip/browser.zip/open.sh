#!/bin/bash

if [ $# -eq 0 ]; then
    echo "Usage: $0 <URL>"
    exit 1
fi

URL=$1
am start -a android.intent.action.VIEW -d "$URL" com.android.chrome
