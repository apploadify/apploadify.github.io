#!/bin/bash

pkg install python3 

pip install discord.py

chmod +x change_python.sh

mkdir /data/data/com.termux/files/home/python

cd /data/data/com.termux/files/home/python

./change_python.sh