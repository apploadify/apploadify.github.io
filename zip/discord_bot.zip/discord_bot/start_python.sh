#!/bin/bash

# Eingabeaufforderung für den Bot-Token
read -p "Bitte geben Sie den Bot-Token ein: " token

# Schreibe den Token in die bot.py Datei
echo "bot.run('$token')" > bot.py

# Bestätigungsnachricht
echo "Der Token wurde erfolgreich in die bot.py Datei geschrieben."

python bot.py